#!/bin/bash
#
#SBATCH --account=ms17q1
#SBATCH --partition=long
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=32
#SBATCH --time=01:30:00
#SBATCH -J LiF
#SBATCH -o logout
#SBATCH --error=err

##-------exports-------------------------------------
export OMP_NUM_THREADS=1
export FOR_FASTMEM_RETRY=T
export MKL_NUM_THREADS=1

### run
module load intel/PSXE2017.u4
srun FlapwMBPT.exe

